create
    definer = stock@localhost procedure Load5Year(IN etime datetime, IN stime datetime, IN cname varchar(45),
                                                  IN cprice float, IN cquantity int)
BEGIN
DECLARE squantity Integer DEFAULT 0;
set squantity = cquantity;
WHILE stime <= etime DO
	
	IF stime + interval '1' year < etime THEN 

			INSERT INTO stock (name,price,time,quantity)
						VALUES
						(cname, cprice, stime,cquantity);
			set cprice = cprice + cprice*(0.001)*power(-1,round(RAND()));
            set stime = stime + interval '1' month;
			set cquantity = cquantity + round(10*(rand()))*power(-1,round(RAND()));
			If cquantity < 0 then
				set cquantity = 0;
			elseif cquantity > squantity then
				set cquantity = squantity;
			end if;
            
	elseif stime + interval '1' year >= etime and month(stime) < month(etime) then
				if weekday(stime) = 0 or week(now()) -1 = week(stime)then
					INSERT INTO stock (name,price,time,quantity)
								VALUES
								(cname, cprice, stime,cquantity);
				end if;
                
				set cprice = cprice + cprice*(0.001)*power(-1,round(RAND()));
                set stime = stime + interval '1' day;
				set cquantity = cquantity + round(10*(rand()))*power(-1,round(RAND()));
				If cquantity < 0 then
					set cquantity = 0;
				elseif cquantity > squantity then
					set cquantity = squantity;
				end if;
     elseif stime + interval '1' year >= etime and month(stime) = month(stime) and day(stime) < day(etime) then
		
			INSERT INTO stock (name,price,time,quantity)
						VALUES
						(cname, cprice, stime,cquantity);
			set cprice = cprice + cprice*(0.001)*power(-1,round(RAND()));
            set stime = stime + interval '1' day;
			set cquantity = cquantity + round(10*(rand()))*power(-1,round(RAND()));
			If cquantity < 0 then
				set cquantity = 0;
			elseif cquantity > squantity then
				set cquantity = squantity;
			end if;
            
	     else
			if weekday(stime) < 5 then
				INSERT INTO stock (name,price,time,quantity)
						VALUES
						(cname, cprice, stime,cquantity);
			end if;
			set cprice = cprice + cprice*(0.001)*power(-1,round(RAND()));
            set stime = stime + interval '60' second;
			set cquantity = cquantity + round(10*(rand()))*power(-1,round(RAND()));
			If cquantity < 0 then
				set cquantity = 0;
			elseif cquantity > squantity then
				set cquantity = squantity;
			end if;
    end if;
end while;
END;

